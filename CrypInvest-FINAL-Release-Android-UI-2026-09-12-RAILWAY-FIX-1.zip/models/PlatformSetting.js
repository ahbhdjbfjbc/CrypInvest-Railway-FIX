const mongoose=require('mongoose');
const schema=new mongoose.Schema({key:{type:String,required:true,unique:true,index:true,trim:true},value:{type:mongoose.Schema.Types.Mixed,default:null}},{timestamps:true});
module.exports=mongoose.model('PlatformSetting',schema);
